import re
import math

from PIL import Image, ImageDraw
from cv2 import imshow
import matplotlib
import matplotlib.colors

S = 10

def plot():
    with open('output.txt', 'r') as f:
        lines = f.readlines()
        W, H = [int(value) for value in re.search(r"(\d+) (\d+)", lines[0]).groups()]

        img = Image.new("RGB", (W*S, (int(H*1.2))*S))
        img1 = ImageDraw.Draw(img)
        draw_grid(img, img1, S)
        #colors
        #green

        n = int(lines[1])
        for line in lines[2:]:
            w, h, x, y, r = [int(value) for value in re.search(r"(\d+) (\d+) (\d+) (\d+) (\d+)", line).groups()]
            print((w, h, x, y, r))
            img1.rectangle([(x*S,y*S),(S*(x+w*(1-r)+h*r),S*(y+h*(1-r)+w*r))], outline='green', width = 5)
        img.show()

def draw_grid(image, draw, S):
    # Draw some lines
    y_start = 0
    color = 'white'
    y_end = image.height
    step_size = 1*S

    for x in range(0, image.width, step_size):
        line = ((x, y_start), (x, y_end))
        draw.line(line, fill=color)

    x_start = 0
    x_end = image.width

    for y in range(0, image.height, step_size):
        line = ((x_start, y), (x_end, y))
        draw.line(line, fill=color)

if __name__ == '__main__':
    plot()


