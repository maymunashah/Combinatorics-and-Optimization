import random

def generate():
    with open('input_data.txt', 'w') as f:
        W = random.randint(2, 20)
        f.write(str(W)+'\n')
        n = random.randint(5, W*3)
        f.write(str(n)+'\n')
        for i in range(0, n):
            h = random.randint(1, 20)
            w = random.randint(1, W)
            f.write(str(w) + " " + str(h) + '\n')

generate()