from ortools.linear_solver import pywraplp
from ortools.init import pywrapinit
from export_data import export_to_txt
from import_data import import_from_txt
from visualize_data import plot

def main():
    # Create the linear solver with the GLOP backend.
    solver = pywraplp.Solver.CreateSolver('SCIP')
    if not solver:
        return
    
    
    W, n, rectangles = import_from_txt()
    # Create the constants
    X_LIMIT = W
    Y_LIMIT = 100*n
    M = 100000 #number to be high enough for the big M method

    # Create the variables
    rect_vars = []
    overlap_vars = []
    for i in range(1, n + 1):
        rect_vars.append((
            solver.IntVar(0, X_LIMIT, "x_"+str(i)),
            solver.IntVar(0, Y_LIMIT, "y_"+str(i)),
            solver.IntVar(0, 1, "r_"+str(i))
        ))
        overlap_vars.append([
            (
            solver.IntVar(0, 1, "z1_"+str(i)+"_"+str(j)),
            solver.IntVar(0, 1, "z2_"+str(i)+"_"+str(j)),
            solver.IntVar(0, 1, "z3_"+str(i)+"_"+str(j)),
            solver.IntVar(0, 1, "z4_"+str(i)+"_"+str(j))
            ) for j in range(i+1, n + 1)
        ])
    H = solver.IntVar(0, Y_LIMIT, "H")
 

    print('Number of variables =', solver.NumVariables())

    # Create a linear constraints
    visited_rect = []
    visited_indexes = []
    # for each rectangle the fit is x + w(1-r) + h*r < W -----> W + (w-h)r - x > w
    #                           and y + h(1-r) + w*r < H -----> y + (w-h)r < L - h
    for i in range(1, n + 1):
        x, y, r = rect_vars[i-1]
        w, h = rectangles[i-1]
        solver.Add(x + w*(1-r) + h*r <= W)
        solver.Add(y + h*(1-r) + w*r <= H)
        if (w==h): solver.Add(r == 0)
        #solver.Add(r == 0)

        for j in range(i+1, n + 1):
            x2,y2,r2 = rect_vars[j-1]
            w2, h2 = rectangles[j-1]
            z1, z2, z3, z4 = overlap_vars[i-1][j-i-1]

            solver.Add(x2 + w2*(1-r2) + h2*r2 <= x + M*z1)
            solver.Add(x + w*(1-r) + h*r <= x2 + M*z2)
            solver.Add(y + h*(1-r) + w*r <= y2 + M*z3)
            solver.Add(y2 + h2*(1-r2) + w2*r2 <= y + M*z4)
            solver.Add(z1 +z2 +z3 +z4 <= 3)
        
        #simmetry breaking
        """
        rect_dims = (h, w)
        if h < w:
            rect_dims = (w, h)
        try:
            index = visited_rect.index(rect_dims)
            k = visited_indexes[index]
            x2,y2,r2 = rect_vars[k]
            solver.Add(M*x - M*x2 + y - y2 <=0)
            visited_indexes[index] = i
            #add constraint
        except ValueError as ve:
            visited_rect.append(rect_dims)
            visited_indexes.append(i)
        """
            

    print('Number of constraints =', solver.NumConstraints())

    # Create the objective function.
    objective = solver.Objective()
    objective.SetCoefficient(H, 1)
    objective.SetMinimization()


    status = solver.Solve()

    if status == pywraplp.Solver.OPTIMAL:
        print('Solution:')
        print('Objective value =', solver.Objective().Value()) 
        export_to_txt(rect_vars, rectangles, H, W, n)
    else:
        print('The problem does not have an optimal solution.')


    print('\nAdvanced usage:')
    print('Problem solved in %f milliseconds' % solver.wall_time())
    print('Problem solved in %d iterations' % solver.iterations())
    print('Problem solved in %d branch-and-bound nodes' % solver.nodes())
    if True:
            plot()


if __name__ == '__main__':
    main()