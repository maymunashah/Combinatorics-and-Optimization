import re

def import_from_txt():
    with open('input_data.txt', 'r') as f:
        lines = f.readlines()

        #first line is the width of the silicon plate
        W = int(lines[0])

        #second line is the number of rectangles
        n = int(lines[1])
        print(str(W) +" "+ str(n))
        rectangles = []
        
        #read each rectangle
        for line in lines[2:2+n]:
            match = re.search(r"(\d+) (\d+)", line).group(1,2)
            x = int(match[0])
            y = int(match[1])
            rectangles.append((x,y))
        return W, n, rectangles