from ortools.linear_solver import pywraplp
from ortools.init import pywrapinit
from ortools.model_builder.python import model_builder_helper
from export_data import export_to_txt
from import_data import import_from_txt
from visualize_data import plot
import sys
import math

def main(W, n, rectangles, rotation = True, sym_break = True, verbose = False):
    # Create the linear solver with the SCIP backend.
    solver = pywraplp.Solver.CreateSolver('SCIP')
    if not solver:
        return
    if verbose: solver.EnableOutput()
    solver.set_time_limit(300000)

    # Create the constants
    X_LIMIT = W
    if rotation:
        Y_LIMIT = sum([min(rect[0], rect[1]) for rect in rectangles])
    else:
        Y_LIMIT = sum([rect[1] for rect in rectangles])
    M = 10000 #number to be high enough for the big M method

    
    # Create the variables
    rect_vars = []
    overlap_vars = []
    total_area = sum([w * h for (w,h) in rectangles])
    for i in range(0, n):
        w, h = rectangles[i]
        if rotation:
            X_LIMIT = W - min([w,h])
        else:
            X_LIMIT = W - w
        rect_vars.append((
            solver.IntVar(0, X_LIMIT, "x_"+str(i)),
            solver.IntVar(0, Y_LIMIT, "y_"+str(i)),
            solver.BoolVar( "r_"+str(i)) if rotation else 0
        ))
        overlap_vars.append([
            (
            solver.BoolVar("z1_"+str(i)+"_"+str(j)),
            solver.BoolVar("z2_"+str(i)+"_"+str(j)),
            solver.BoolVar("z3_"+str(i)+"_"+str(j)),
            solver.BoolVar("z4_"+str(i)+"_"+str(j))
            ) for j in range(i+1, n)
        ])
    H = solver.IntVar(math.ceil(total_area/W), Y_LIMIT, "H")
 

    print('Number of variables =', solver.NumVariables())

    # Create constraints
    visited_rect = []
    visited_indexes = []
    simmetry_breakings = 0
    for i in range(0, n):
        x, y, r = rect_vars[i]
        w, h = rectangles[i]
        #Bound constraints
        solver.Add(x + w*(1-r) + h*r <= W)
        solver.Add(y + h*(1-r) + w*r <= H)   

        #similar rectangles simmetry breaking
        if sym_break:
            rect_dims = (h, w)
            if h < w or not rotation:
                rect_dims = (w, h)
            try:
                index = visited_rect.index(rect_dims)
                k = visited_indexes[index]
                x2,y2,r2 = rect_vars[k]
                z1, z2, z3, z4 = overlap_vars[k][i-k-1]
                solver.Add(z1 == 1)
                solver.Add(z4 == 1)
                simmetry_breakings = simmetry_breakings + 1
                visited_indexes[index] = i
            except ValueError as ve:
                visited_rect.append(rect_dims)
                visited_indexes.append(i)     

        #No overalp constraints
        for j in range(i+1, n):
            x2,y2,r2 = rect_vars[j]
            w2, h2 = rectangles[j]
            z1, z2, z3, z4 = overlap_vars[i][j-i-1]

            #z1 left, z2 right, z3 up, z4 down  || 0-active, 1-inactive

            solver.Add(x2 + w2*(1-r2) + h2*r2 <= x + M*z1)
            solver.Add(x + w*(1-r) + h*r <= x2 + M*z2)
            solver.Add(y + h*(1-r) + w*r <= y2 + M*z3)
            solver.Add(y2 + h2*(1-r2) + w2*r2 <= y + M*z4)
            solver.Add(z1 +z2 +z3 +z4 <= 3)

        #rotation simmetry breaking
        if sym_break:
            if (w==h) or not rotation: 
                solver.Add(r == 0)
                if rotation: simmetry_breakings = simmetry_breakings + 1
        
        
    if sym_break:    
        #Lexicograph constraint of the two biggest rectangles
        rect_areas = [w * h for (w,h) in rectangles]
        max_index = rect_areas.index(max(rect_areas))
        #solver.Add(rect_vars[max_index][0] == 0)
        #solver.Add(rect_vars[max_index][1] == 0)
        rect_areas[max_index] = 0
        max_index_2 = rect_areas.index(max(rect_areas))
        if max_index > max_index_2:
            z1, z2, z3, z4 = overlap_vars[max_index_2][max_index - max_index_2 -1]
            solver.Add(z2 == 1)
            solver.Add(z3 == 1)
        else:
            z1, z2, z3, z4 = overlap_vars[max_index][max_index_2 - max_index -1]
            solver.Add(z1 == 1)
            solver.Add(z4 == 1)
        x, y, r = rect_vars[max_index]
        x2, y2, r2 = rect_vars[max_index_2]
        simmetry_breakings += 2

        
        #size Gradient on the x axis simmetry breaking
        #the total constraint is sum(side[i]) < sum(1-side[i]) -----> 2*sum(side[i]) < n
        side_var = []
        grad_cons = solver.RowConstraint(n, 2*n, "grad_cons")
        for i in range(0, n):
            side_var.append(
                solver.BoolVar("side_"+str(i))
            )
            x, y, r = rect_vars[i]
            w, h = rectangles[i]
            side = side_var[i]
            solver.Add( x + ((w*(1-r) + h*r)/2)  <= (W)/2  + W/2*side )
            solver.Add( x + ((w*(1-r) + h*r)/2) >= (W)/2 - W/2*(1-side) )
            grad_cons.SetCoefficient(side, 2)
            simmetry_breakings += 2
        simmetry_breakings += 1

        if rotation:
            #size Gradient on big area rectangles
            rect_areas = [(w * h, index) for index,(w,h) in enumerate(rectangles)]
            rect_areas.sort(key = lambda x: x[0], reverse= True)
            from itertools import accumulate
            cumsum_areas = list(accumulate([areas for areas, index in rect_areas]))
            big_n = next(i for i, v in enumerate(cumsum_areas) if v > total_area/2)
            big_rects = [index for area, index in rect_areas[: max(2,big_n*2)]]
            big_side_var = []
            big_grad_cons = solver.RowConstraint(0, len(big_rects), "big_grad_cons")
            for k, i in enumerate(big_rects):
                big_side_var.append(
                    solver.BoolVar("big_side_"+str(i))
                )
                x, y, r = rect_vars[i]
                w, h = rectangles[i]
                side = big_side_var[k]
                solver.Add( x + ((w*(1-r) + h*r)/2)  <= (W)/2  + W/2*side )
                solver.Add( x + ((w*(1-r) + h*r)/2) >= (W)/2 - W/2*(1-side) )
                big_grad_cons.SetCoefficient(side, 2)
                simmetry_breakings += 2
            simmetry_breakings += 1
            print(cumsum_areas)
            print("totale_are/2: %f" % (total_area/2))
            print(big_rects)



            
    print('Number of constraints =', solver.NumConstraints())
    print('Number of simm breaking contraints =', simmetry_breakings)

    # Create the objective function.
    objective = solver.Objective()
    objective.SetCoefficient(H, 1)
    objective.SetMinimization()

    solver.SetSolverSpecificParametersAsString("display/verblevel = 4")
    solver.SetSolverSpecificParametersAsString("display/freq = 500")
    solver.SetSolverSpecificParametersAsString("parallel/maxnthreads = 16")
    
    status = solver.Solve()

    if status == pywraplp.Solver.OPTIMAL:
        print('Solution:')
        print('Objective value =', solver.Objective().Value()) 
        print('Plate height = ', H.solution_value())
    else:
        print('The problem does not have an optimal solution.')
    if status == pywraplp.Solver.INFEASIBLE:
        return (Y_LIMIT, [0 for i in range(0, n)], [0 for i in range(0, n)], [rect[0] for rect in rectangles], [rect[1] for rect in rectangles])


    print('\nAdvanced usage:')
    print('Problem solved in %f milliseconds' % solver.wall_time())
    print('Problem solved in %d iterations' % solver.iterations())
    print('Problem solved in %d branch-and-bound nodes' % solver.nodes())
    if verbose:
        try: print([side.solution_value() for side in side_var])
        except: pass
        try:
            print([side.solution_value() for side in big_side_var])
            from operator import itemgetter 
            print([itemgetter(*[i for k,i in enumerate (big_rects)])(rectangles)])
        except: pass

    #return of items H, Xs, Ys, Ws, Hs
    Xs = [x.solution_value() for (x,y,r) in rect_vars]
    Ys = [y.solution_value() for (x,y,r) in rect_vars]
    Ws = [rectangles[i][0] if r.solution_value()<1 else rectangles[i][1] for i,(x,y,r) in enumerate(rect_vars)]
    Hs = [rectangles[i][1] if r.solution_value()<1 else rectangles[i][0] for i,(x,y,r) in enumerate(rect_vars)]
    return (H.solution_value(), Xs, Ys, Ws, Hs, solver.wall_time()/1000)





if __name__ == '__main__':
    filename = sys.argv[1]
    W, n, rectangles = import_from_txt(filename=filename)
    H, Xs, Ys, Ws, Hs, time = main(W, n, rectangles)
    print(H)
    print(Xs)
    print(Ys)
    print(Ws)
    print(Hs)
    print(time)