import re

def export_to_txt(rect_vars, rectangles, H, W, n, filename = "output.txt" ):
    with open(filename[:-4]+"_output.txt", 'w') as f:
        f.write(str(W)+" "+f'{H.solution_value():.0f}'+ '\n')
        f.write(str(n)+'\n')
        for i in range(0, n):
            x,y,r = rect_vars[i]
            w, h = rectangles[i]
            f.write(
                str(w)+ " "+
                str(h)+ " "+
                f'{x.solution_value():.0f}'+ " "+
                f'{y.solution_value():.0f}'+ " "+
                f'{r if isinstance(r, int) else r.solution_value():.0f}'+ '\n'
            )