import re

def import_from_txt(filename):
    if not filename:
        filename = 'input_data.txt'
    with open(filename, 'r') as f:
        lines = f.readlines()

        #first line is the width of the silicon plate
        W = int(lines[0])

        #second line is the number of rectangles
        n = int(lines[1])
        print(str(W) +" "+ str(n))
        rectangles = []
        
        #read each rectangle
        for line in lines[2:2+n]:
            match = re.search(r"(\d+) (\d+)", line).group(1,2)
            x = int(match[0])
            y = int(match[1])
            rectangles.append((x,y))
        print(rectangles)
        return W, n, rectangles

def import_from_dzn(filename):
    if not filename:
        filename = 'data1.dzn'
    with open(filename, 'r') as f:
        lines = f.readlines()
        print(lines)

        #first line is the width of the silicon plate
        W = int(re.search(r'plate_width=(\d+)', lines[0]).group(1))

        #second line is the number of rectangles
        n = int(re.search(r'n=(\d+)', lines[1]).group(1))
        print(str(W) +" "+ str(n))
        rectangles = []
        w_values = re.search(r'x\_i\=\[([\d\,]+)\]', lines[2]).group(1)
        w_values = re.split(r'\,', w_values)
        h_values = re.search(r'y\_i\=\[([\d\,]+)\]', lines[3]).group(1)
        h_values = re.split(r'\,', h_values)
        
        #read each rectangle
        for i in range(0, n):
            x = int(w_values[i])
            y = int(h_values[i])
            rectangles.append((x,y))
        print(rectangles)
        return W, n, rectangles